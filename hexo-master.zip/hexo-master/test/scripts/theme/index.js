'use strict';

describe('Theme', () => {
  require('./theme');
  require('./view');
});
