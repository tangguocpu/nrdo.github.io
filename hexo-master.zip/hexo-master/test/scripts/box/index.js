'use strict';

describe('Box', () => {
  require('./box');
  require('./file');
});
